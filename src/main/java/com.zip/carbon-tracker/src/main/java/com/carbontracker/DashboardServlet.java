package com.carbontracker;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        double today = 0, weekly = 0, monthly = 0;

        try {
            Connection con = DBUtil.getConnection();

            // Today
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT SUM(total_co2) FROM carbon_history WHERE entry_date = CURDATE()");
            ResultSet rs1 = ps1.executeQuery();
            if (rs1.next()) today = rs1.getDouble(1);

            // Weekly
            PreparedStatement ps2 = con.prepareStatement(
                "SELECT SUM(total_co2) FROM carbon_history WHERE YEARWEEK(entry_date, 1) = YEARWEEK(CURDATE(), 1)");
            ResultSet rs2 = ps2.executeQuery();
            if (rs2.next()) weekly = rs2.getDouble(1);

            // Monthly
            PreparedStatement ps3 = con.prepareStatement(
                "SELECT SUM(total_co2) FROM carbon_history WHERE MONTH(entry_date) = MONTH(CURDATE()) AND YEAR(entry_date) = YEAR(CURDATE())");
            ResultSet rs3 = ps3.executeQuery();
            if (rs3.next()) monthly = rs3.getDouble(1);

            con.close();
        } catch (Exception e) {
            e.printStackTrace(out);
        }

        out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Dashboard</title>");
        out.println("<link rel='stylesheet' href='style.css'></head><body>");

        out.println("<header><h1>📊 Dashboard</h1>");
        out.println("<nav><a href='index.html'>Home</a><a href='DashboardServlet'>Dashboard</a><a href='HistoryServlet'>History</a></nav></header>");

        out.println("<main><section class='card'>");
        out.println("<h2>CO₂ Summary</h2>");
        out.println("<p><b>Today:</b> " + today + " kg</p>");
        out.println("<p><b>This Week:</b> " + weekly + " kg</p>");
        out.println("<p><b>This Month:</b> " + monthly + " kg</p>");
        out.println("</section></main>");

        out.println("</body></html>");
    }
}
